import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { REGIONS } from "@/data/types";
import { AlertTriangle, ExternalLink, MapPin, RefreshCw } from "lucide-react";
import { Link } from "@tanstack/react-router";

export const Route = createFileRoute("/map")({
  head: () => ({
    meta: [
      { title: "Map — RDR1 Guide" },
      { name: "description", content: "Same-page world map panel for Red Dead Redemption." },
    ],
  }),
  component: MapPage,
});

const MAP_URL = "https://www.ign.com/maps/red-dead-redemption/world";

function MapPage() {
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [status, setStatus] = useState<"loading" | "ready" | "blocked">("loading");
  const [reloadKey, setReloadKey] = useState(0);

  useEffect(() => {
    setStatus("loading");
    // If the iframe doesn't fire load within a reasonable window, assume blocked.
    const timeout = window.setTimeout(() => {
      setStatus((s) => (s === "loading" ? "blocked" : s));
    }, 7000);
    return () => window.clearTimeout(timeout);
  }, [reloadKey]);

  const handleLoad = () => {
    try {
      // Cross-origin access will throw — that's actually fine, means content loaded.
      // If we can access location, it's likely an about:blank error page.
      const href = iframeRef.current?.contentWindow?.location.href;
      if (href === "about:blank") {
        setStatus("blocked");
        return;
      }
      setStatus("ready");
    } catch {
      // Cross-origin — normal, means external content rendered.
      setStatus("ready");
    }
  };

  return (
    <div className="h-screen flex flex-col">
      <div className="hairline-b bg-panel/40 px-6 py-4 flex flex-wrap items-end justify-between gap-3">
        <div>
          <div className="text-xs uppercase tracking-[0.2em] text-brass-dim">World</div>
          <h1 className="mt-0.5 font-display text-3xl text-parchment">Map</h1>
          <p className="mt-1 text-sm text-muted-foreground max-w-2xl">
            Embedded IGN interactive world map. If the source blocks embedding, use the
            region jump-links below to filter the Locations tracker.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setReloadKey((k) => k + 1)}
            className="inline-flex items-center gap-1.5 rounded-md border border-hairline px-3 py-2 text-xs text-parchment hover:border-brass/40"
          >
            <RefreshCw className="h-3.5 w-3.5" /> Reload
          </button>
        </div>
      </div>

      <div className="flex-1 min-h-0 grid grid-cols-1 lg:grid-cols-[minmax(0,1fr)_280px]">
        <div className="relative min-h-0 bg-ink">
          <iframe
            key={reloadKey}
            ref={iframeRef}
            src={MAP_URL}
            title="RDR1 Map"
            onLoad={handleLoad}
            className="absolute inset-0 h-full w-full border-0"
          />
          {status !== "ready" ? (
            <div className="absolute inset-0 flex items-center justify-center bg-ink/95 backdrop-blur-sm">
              <MapFallback status={status} />
            </div>
          ) : null}
        </div>

        <aside className="hairline-t lg:hairline-t-0 lg:border-l lg:border-hairline overflow-y-auto p-4 bg-panel/40">
          <h2 className="font-display text-parchment text-lg mb-3">Region jump</h2>
          <div className="space-y-1">
            {REGIONS.map((r) => (
              <Link
                key={r}
                to="/locations"
                className="flex items-center gap-2 rounded-md px-3 py-2 text-sm text-parchment/85 hover:bg-accent/40"
              >
                <MapPin className="h-3.5 w-3.5 text-brass shrink-0" />
                {r}
              </Link>
            ))}
          </div>
        </aside>
      </div>
    </div>
  );
}

function MapFallback({ status }: { status: "loading" | "blocked" }) {
  if (status === "loading") {
    return (
      <div className="text-center text-sm text-muted-foreground">
        <div className="inline-flex h-8 w-8 items-center justify-center rounded-full border border-brass/40">
          <RefreshCw className="h-4 w-4 text-brass animate-spin" />
        </div>
        <div className="mt-3 font-display text-parchment text-lg">Loading map…</div>
      </div>
    );
  }
  return (
    <div className="max-w-md text-center px-8">
      <AlertTriangle className="h-8 w-8 text-ember mx-auto" />
      <div className="mt-3 font-display text-parchment text-xl">Map source blocked embedding</div>
      <p className="mt-2 text-sm text-muted-foreground">
        IGN's map won't render inside another site. Use the region jump-links on the
        right to filter Locations, or open the map in a new tab as a last resort.
      </p>
      <div className="mt-4 flex justify-center gap-2">
        <a
          href={MAP_URL}
          target="_blank"
          rel="noreferrer"
          className="inline-flex items-center gap-1.5 rounded-md border border-brass/40 px-3 py-2 text-xs text-brass hover:bg-brass/10"
        >
          <ExternalLink className="h-3.5 w-3.5" /> Open IGN map
        </a>
      </div>
      <div className="mt-6 text-xs text-muted-foreground border-t border-hairline pt-4">
        Reserved for a future in-app map tile layer.
      </div>
    </div>
  );
}
