import { useProgress, type ItemProgress } from "@/lib/progress";
import type { Trackable } from "@/data/types";
import { Check, Pin, PinOff, AlertTriangle, MapPin, Sparkles, Trophy } from "lucide-react";
import { Fragment } from "react";

interface DetailPanelProps {
  item: Trackable | null;
}

function Section({
  title,
  icon: Icon,
  children,
  tone = "default",
}: {
  title: string;
  icon?: React.ComponentType<{ className?: string }>;
  children: React.ReactNode;
  tone?: "default" | "warn";
}) {
  return (
    <section className="rounded-lg border border-hairline bg-panel/60 p-4">
      <div className="flex items-center gap-2 mb-2">
        {Icon ? (
          <Icon
            className={`h-4 w-4 ${tone === "warn" ? "text-ember" : "text-brass"}`}
          />
        ) : null}
        <h3 className="text-xs uppercase tracking-[0.18em] text-muted-foreground">
          {title}
        </h3>
      </div>
      {children}
    </section>
  );
}

export function DetailPanel({ item }: DetailPanelProps) {
  const items = useProgress((s) => s.items);
  const toggle = useProgress((s) => s.toggleItem);
  const toggleStep = useProgress((s) => s.toggleStep);
  const togglePin = useProgress((s) => s.togglePin);
  const setNote = useProgress((s) => s.setNote);

  if (!item) {
    return (
      <div className="h-full flex flex-col items-center justify-center text-center px-8 py-16 text-muted-foreground">
        <Sparkles className="h-8 w-8 text-brass-dim mb-3" />
        <div className="font-display text-parchment text-lg">Select an entry</div>
        <p className="mt-1 text-sm max-w-sm">
          Pick a mission, challenge or location from the list to see the full walkthrough.
        </p>
      </div>
    );
  }

  const p: ItemProgress = items[item.id] ?? { done: false, steps: {} };

  return (
    <div className="h-full overflow-y-auto">
      <div className="mx-auto max-w-3xl px-6 py-6 space-y-5">
        {/* Header */}
        <header className="space-y-3">
          <div className="flex items-start justify-between gap-4">
            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-2 text-[11px] uppercase tracking-[0.18em] text-brass-dim">
                <span>{item.region}</span>
                <span className="text-hairline">•</span>
                <span>{item.category}</span>
                {item.isRequiredForOfficial100 ? (
                  <>
                    <span className="text-hairline">•</span>
                    <span className="text-brass">Official 100%</span>
                  </>
                ) : null}
              </div>
              <h1 className="mt-1 font-display text-3xl text-parchment">{item.title}</h1>
              <p className="mt-2 text-sm text-muted-foreground">{item.summary}</p>
            </div>
            <div className="flex flex-col items-end gap-2 shrink-0">
              <button
                onClick={() => toggle(item.id)}
                className={`inline-flex items-center gap-2 rounded-md px-4 py-2.5 text-sm font-medium transition-colors min-h-11 ${
                  p.done
                    ? "bg-brass text-primary-foreground"
                    : "border border-brass/40 text-brass hover:bg-brass/10"
                }`}
              >
                <Check className="h-4 w-4" />
                {p.done ? "Completed" : "Mark complete"}
              </button>
              <button
                onClick={() => togglePin(item.id)}
                className="inline-flex items-center gap-2 rounded-md px-3 py-1.5 text-xs text-muted-foreground hover:text-parchment"
              >
                {p.pinned ? <PinOff className="h-3 w-3" /> : <Pin className="h-3 w-3" />}
                {p.pinned ? "Unpin" : "Pin"}
              </button>
            </div>
          </div>
        </header>

        {/* Walkthrough */}
        <Section title="Walkthrough">
          <p className="text-[15px] leading-relaxed text-parchment/90 whitespace-pre-line">
            {item.descriptiveWalkthrough}
          </p>
        </Section>

        {/* Key objectives */}
        {item.keyObjectives.length ? (
          <Section title="Key objectives">
            <ul className="space-y-1.5">
              {item.keyObjectives.map((o, i) => (
                <li key={i} className="flex items-start gap-2 text-sm text-parchment/85">
                  <span className="mt-1.5 h-1 w-1 rounded-full bg-brass shrink-0" />
                  <span>{o}</span>
                </li>
              ))}
            </ul>
          </Section>
        ) : null}

        {/* Checklist */}
        {item.checklistSteps.length ? (
          <Section title="Checklist">
            <ul className="space-y-1.5">
              {item.checklistSteps.map((step) => {
                const done = !!p.steps[step.id];
                return (
                  <li key={step.id}>
                    <button
                      onClick={() => toggleStep(item.id, step.id)}
                      className={`flex w-full items-center gap-3 rounded-md px-3 py-2.5 text-left text-sm transition-colors min-h-11 ${
                        done
                          ? "bg-brass/10 text-parchment"
                          : "hover:bg-accent/40 text-parchment/85"
                      }`}
                    >
                      <span
                        className={`flex h-5 w-5 items-center justify-center rounded border shrink-0 ${
                          done ? "bg-brass border-brass" : "border-hairline"
                        }`}
                      >
                        {done ? <Check className="h-3.5 w-3.5 text-primary-foreground" /> : null}
                      </span>
                      <span className={done ? "line-through opacity-70" : ""}>
                        {step.label}
                      </span>
                    </button>
                  </li>
                );
              })}
            </ul>
          </Section>
        ) : null}

        {/* Rewards */}
        {item.rewardsOrOutcomes.length ? (
          <Section title="Rewards & outcomes" icon={Trophy}>
            <ul className="space-y-1.5">
              {item.rewardsOrOutcomes.map((r, i) => (
                <li key={i} className="text-sm text-parchment/85">
                  {r}
                </li>
              ))}
            </ul>
          </Section>
        ) : null}

        {/* Missables */}
        {item.missableWarnings?.length ? (
          <Section title="Missables" icon={AlertTriangle} tone="warn">
            <ul className="space-y-1.5">
              {item.missableWarnings.map((m, i) => (
                <li key={i} className="text-sm text-ember/90">
                  {m}
                </li>
              ))}
            </ul>
          </Section>
        ) : null}

        {/* Follow-ups */}
        {item.followUpOpportunities?.length ? (
          <Section title="After this, look at">
            <ul className="space-y-1.5">
              {item.followUpOpportunities.map((f, i) => (
                <li key={i} className="text-sm text-parchment/80">
                  {f}
                </li>
              ))}
            </ul>
          </Section>
        ) : null}

        {/* Map markers */}
        {item.mapMarkers?.length ? (
          <Section title="Map references" icon={MapPin}>
            <ul className="space-y-1">
              {item.mapMarkers.map((m, i) => (
                <li key={i} className="text-sm text-parchment/80">
                  <span className="text-brass">{m.label}</span>
                  {m.region ? (
                    <span className="text-muted-foreground"> — {m.region}</span>
                  ) : null}
                  {m.note ? (
                    <Fragment>
                      <br />
                      <span className="text-xs text-muted-foreground">{m.note}</span>
                    </Fragment>
                  ) : null}
                </li>
              ))}
            </ul>
          </Section>
        ) : null}

        {/* Notes */}
        <Section title="Your notes">
          <textarea
            value={p.notes ?? ""}
            onChange={(e) => setNote(item.id, e.target.value)}
            rows={3}
            placeholder="Reminders, save file spots, honor state…"
            className="w-full resize-none rounded-md border border-hairline bg-background/40 px-3 py-2 text-sm text-parchment placeholder:text-muted-foreground focus:border-brass focus:outline-none"
          />
        </Section>
      </div>
    </div>
  );
}
