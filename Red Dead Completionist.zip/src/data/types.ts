export type Region =
  | "New Austin"
  | "West Elizabeth"
  | "Nuevo Paraiso"
  | "Blackwater"
  | "Tall Trees"
  | "Great Plains"
  | "Cholla Springs"
  | "Gaptooth Ridge"
  | "Hennigan's Stead"
  | "Rio Bravo"
  | "Perdido"
  | "Punta Orgullo"
  | "Diez Coronas"
  | "Other";

export const REGIONS: Region[] = [
  "New Austin",
  "West Elizabeth",
  "Nuevo Paraiso",
  "Blackwater",
  "Tall Trees",
  "Great Plains",
  "Cholla Springs",
  "Gaptooth Ridge",
  "Hennigan's Stead",
  "Rio Bravo",
  "Perdido",
  "Punta Orgullo",
  "Diez Coronas",
  "Other",
];

export type CategoryId =
  | "story"
  | "strangers"
  | "challenges"
  | "bounties"
  | "jobs"
  | "hideouts"
  | "minigames"
  | "collectibles"
  | "locations"
  | "outfits"
  | "weapons"
  | "safehouses";

export interface ChecklistStep {
  id: string;
  label: string;
}

export interface MapMarker {
  label: string;
  region?: Region;
  note?: string;
}

export interface TrackableBase {
  id: string;
  title: string;
  category: CategoryId;
  region: Region;
  /**
   * True if this record counts toward Rockstar's official 100% completion
   * total (IGN-verified). Source of truth for the "Official 100%" mode.
   */
  isRequiredForOfficial100: boolean;
  /**
   * Legacy alias — same value as isRequiredForOfficial100. Prefer the
   * `isOfficial(t)` selector in new code.
   */
  isOfficial100?: boolean;
  /**
   * True if this record is tracked for the completionist experience but
   * is NOT part of the official 100% checklist (achievements, cosmetic
   * outfits, cleanup sets, etc.). Mutually exclusive with the official
   * flag above.
   */
  isCompletionistExtra?: boolean;
  /**
   * Optional finer classification, e.g. "rare-weapon" /
   * "completionist-weapon" / "outfit-scrap-chain" / "map-discovery".
   */
  categorySubtype?: string;
  isOptionalSideContent: boolean;
  unlocksAfter?: string[];
  summary: string;
  descriptiveWalkthrough: string;
  keyObjectives: string[];
  rewardsOrOutcomes: string[];
  followUpOpportunities?: string[];
  relatedCollectibles?: string[];
  missableWarnings?: string[];
  checklistSteps: ChecklistStep[];
  mapMarkers?: MapMarker[];
  tags?: string[];
}

// -----------------------------------------------------------------------
// Selectors — the app should read Official vs Extra via these helpers so
// individual data files can be edited without touching consumers.
// -----------------------------------------------------------------------
export function isOfficial(t: Pick<TrackableBase, "isRequiredForOfficial100" | "isOfficial100">): boolean {
  return t.isOfficial100 ?? t.isRequiredForOfficial100;
}
export function isExtra(t: Pick<TrackableBase, "isRequiredForOfficial100" | "isOfficial100" | "isCompletionistExtra">): boolean {
  if (t.isCompletionistExtra !== undefined) return t.isCompletionistExtra;
  return !isOfficial(t);
}

export interface StoryMission extends TrackableBase {
  category: "story";
  missionGiver: string;
  chapter: string;
}

export interface StrangerMission extends TrackableBase {
  category: "strangers";
  missionGiver: string;
  chain?: string;
  step?: number;
}

export interface Challenge extends TrackableBase {
  category: "challenges";
  challengeType: "Hunting" | "Sharpshooter" | "Survivalist" | "Treasure Hunter" | "Tomahawk" | "Explosive Rifle";
  ranks: { rank: number; requirement: string }[];
}

export interface Bounty extends TrackableBase {
  category: "bounties";
  bountyValue?: string;
  aliveOrDead?: "Alive" | "Dead" | "Either";
}

export interface Job extends TrackableBase {
  category: "jobs";
  jobType: string;
  payout?: string;
}

export interface Hideout extends TrackableBase {
  category: "hideouts";
  gang?: string;
}

export interface Minigame extends TrackableBase {
  category: "minigames";
  gameType: string;
  locations: string[];
}

export interface Collectible extends TrackableBase {
  category: "collectibles";
  collectibleType: string;
  count?: number;
}

export interface LocationEntry extends TrackableBase {
  category: "locations";
  locationType: "Town" | "Settlement" | "Landmark" | "Property" | "Point of Interest";
}

export interface Outfit extends TrackableBase {
  category: "outfits";
  unlockMethod: string;
}

export interface Weapon extends TrackableBase {
  category: "weapons";
  weaponType: string;
  ammo?: string;
}

export interface Safehouse extends TrackableBase {
  category: "safehouses";
  cost?: string;
}

export type Trackable =
  | StoryMission
  | StrangerMission
  | Challenge
  | Bounty
  | Job
  | Hideout
  | Minigame
  | Collectible
  | LocationEntry
  | Outfit
  | Weapon
  | Safehouse;

export interface CategoryMeta {
  id: CategoryId;
  label: string;
  shortLabel: string;
  description: string;
  icon: string;
}
