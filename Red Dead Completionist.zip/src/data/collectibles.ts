import type { Collectible } from "./types";

/**
 * Collectibles is a COMPLETIONIST TRACKING category — none of these entries
 * are part of Rockstar's / IGN's official 100% checklist as standalone
 * counters. The underlying pickups (treasure maps, wild flowers) are
 * scored through the Challenges category instead. Sets are surfaced here
 * for players who want a single-pane checklist of every collectable in
 * the game.
 */

export const COLLECTIBLES: Collectible[] = [
  {
    id: "collectible-treasure-maps",
    title: "Treasure Maps (Set of 9)",
    category: "collectibles",
    collectibleType: "Treasure Map",
    region: "Other",
    isRequiredForOfficial100: false,
    isCompletionistExtra: true,
    categorySubtype: "collection-mirror",
    isOptionalSideContent: true,
    count: 9,
    summary: "Mirror tracker for the 9 Treasure Hunter maps (also scored via Challenges).",
    descriptiveWalkthrough:
      "Rockstar counts these under the Treasure Hunter challenge, not as a separate collectible set. Duplicated here for players who prefer a per-map checklist.",
    keyObjectives: ["Find and dig all 9 treasures"],
    rewardsOrOutcomes: ["Cash per treasure", "Treasure Hunter Outfit at Rank 9"],
    checklistSteps: Array.from({ length: 9 }, (_, i) => ({
      id: `t${i + 1}`,
      label: `Treasure ${i + 1}`,
    })),
    tags: ["treasure", "mirror"],
  },
  {
    id: "collectible-wild-flowers",
    title: "Wild Flowers (Survivalist Set)",
    category: "collectibles",
    collectibleType: "Flowers",
    region: "Other",
    isRequiredForOfficial100: false,
    isCompletionistExtra: true,
    categorySubtype: "collection-mirror",
    isOptionalSideContent: true,
    summary: "Mirror tracker for the Survivalist flower pick list (scored via Challenges).",
    descriptiveWalkthrough:
      "Buy the Survivalist Map first. Sweep New Austin, Nuevo Paraíso and finally West Elizabeth. Tall Trees Feverfew is gated by story progress.",
    keyObjectives: ["Pick every flower requirement across all 9 ranks"],
    rewardsOrOutcomes: ["Elegant Suit"],
    checklistSteps: [
      { id: "s1", label: "New Austin flora complete" },
      { id: "s2", label: "Nuevo Paraíso flora complete" },
      { id: "s3", label: "West Elizabeth flora complete" },
    ],
    tags: ["flora", "mirror"],
  },
  {
    id: "collectible-outfit-scraps",
    title: "Outfit Scrap Hunts (Cleanup)",
    category: "collectibles",
    collectibleType: "Outfit fragments",
    region: "Other",
    isRequiredForOfficial100: false,
    isCompletionistExtra: true,
    categorySubtype: "cleanup",
    isOptionalSideContent: true,
    summary: "Aggregate cleanup tracker for outfit component pickups (Bandit, U.S. Marshal, Rancher).",
    descriptiveWalkthrough:
      "Not a formal in-game category. Useful for pre-cleaning outfits before the story gates the last piece.",
    keyObjectives: ["Progress each outfit's unlock chain"],
    rewardsOrOutcomes: ["Faster outfit completion"],
    checklistSteps: [
      { id: "bandit", label: "Bandit scraps" },
      { id: "marshal", label: "U.S. Marshal scraps" },
      { id: "rancher", label: "Rancher scraps" },
    ],
    tags: ["cleanup", "outfits"],
  },
  {
    id: "collectible-legendary-animals",
    title: "Legendary Animals",
    category: "collectibles",
    collectibleType: "Rare Kills",
    region: "Other",
    isRequiredForOfficial100: false,
    isCompletionistExtra: true,
    categorySubtype: "cleanup",
    isOptionalSideContent: true,
    summary: "Legendary Bear (Khan Tanka), Cougars, and other rare hunt targets.",
    descriptiveWalkthrough:
      "Cleanup checklist for the game's rare kills. Only Khan Tanka indirectly affects 100% (via Master Hunter Rank 10). The rest are prestige-only.",
    keyObjectives: ["Skin each legendary animal"],
    rewardsOrOutcomes: ["Bragging rights + rare pelts"],
    checklistSteps: [
      { id: "khan-tanka", label: "Khan Tanka (Legendary Bear)" },
      { id: "cougars", label: "Cougar cluster hunts" },
      { id: "buffalo", label: "American Buffalo herd" },
    ],
    tags: ["hunting"],
  },
];

