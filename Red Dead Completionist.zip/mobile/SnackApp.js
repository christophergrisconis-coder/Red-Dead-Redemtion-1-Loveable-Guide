/**
 * RDR1 Completionist — Single-file Expo Snack build.
 *
 * HOW TO USE (Expo Snack):
 *   1. Go to https://snack.expo.dev  → click "+ New Snack".
 *   2. In the file tree on the left, open App.js.
 *   3. Select ALL of App.js and DELETE it.
 *   4. Paste the entire contents of this file into App.js.
 *   5. Open the "Dependencies" panel (left sidebar, bottom) and add:
 *        - @react-native-async-storage/async-storage
 *      (Snack ships React Navigation-free — this file uses only core RN,
 *       so no other deps are needed. AsyncStorage is optional; if you
 *       skip it, progress just won't persist across reloads.)
 *   6. On the right, choose "My Device" and scan the QR with Expo Go,
 *      or pick the iOS/Android/Web preview.
 *
 * Works on iPhone, iPad (landscape gets a split master/detail), and Web.
 */

import React, { useEffect, useMemo, useState, useCallback } from 'react';
import {
  SafeAreaView,
  View,
  Text,
  ScrollView,
  FlatList,
  Pressable,
  TextInput,
  StyleSheet,
  useWindowDimensions,
  Share,
  Alert,
  Linking,
  Platform,
  StatusBar,
} from 'react-native';

// Optional persistence — falls back to in-memory if the dep isn't added.
let AsyncStorage = null;
try {
  // eslint-disable-next-line global-require
  AsyncStorage = require('@react-native-async-storage/async-storage').default;
} catch (e) {
  AsyncStorage = null;
}

// ---------------------------------------------------------------------------
// THEME
// ---------------------------------------------------------------------------
const T = {
  bg: '#14100b',
  bgElev: '#1c1712',
  surface: '#221b14',
  border: '#3a2e22',
  borderStrong: '#4a3a2a',
  parchment: '#e9d9b8',
  parchmentDim: '#b8a686',
  muted: '#8a7a62',
  brass: '#c9a24b',
  brassDim: '#8a6d2f',
  accent: '#d7823a',
  official: '#c9a24b',
  extra: '#7a8ea0',
};

// ---------------------------------------------------------------------------
// CATEGORIES (IGN-verified official counts)
// ---------------------------------------------------------------------------
const CATEGORIES = [
  { id: 'story',       label: 'Story Missions',    icon: '🎯', official: 57, extras: 0, desc: 'All 57 storyline missions.' },
  { id: 'strangers',   label: 'Stranger Missions', icon: '🪶', official: 18, extras: 1, desc: 'Side stories; 18 count toward 100%.' },
  { id: 'challenges',  label: 'Ambient Challenges',icon: '🎖', official: 4,  extras: 2, desc: 'Hunting, Sharpshooter, Survivalist, Treasure Hunter.' },
  { id: 'bounties',    label: 'Bounty Locations',  icon: '📜', official: 20, extras: 0, desc: '20 bounty locations across 3 provinces.' },
  { id: 'jobs',        label: 'Ambient Jobs',      icon: '🤠', official: 5,  extras: 0, desc: 'Nightwatch + Horsebreaking shifts.' },
  { id: 'hideouts',    label: 'Gang Hideouts',     icon: '🏚', official: 7,  extras: 1, desc: 'Clear each hideout once in free roam.' },
  { id: 'minigames',   label: 'Minigames',         icon: '🎲', official: 6,  extras: 0, desc: 'Win each of 6 minigame types.' },
  { id: 'locations',   label: 'Map Locations',     icon: '🗺', official: 94, extras: 0, desc: 'Discover all 94 named locations.' },
  { id: 'outfits',     label: 'Key Outfits',       icon: '👕', official: 9,  extras: 3, desc: '9 key outfits per IGN checklist.' },
  { id: 'weapons',     label: 'Rare Weapons',      icon: '🔫', official: 5,  extras: 5, desc: 'LeMat, Semi-Auto Shotgun, Carcano, Mauser, Evans.' },
  { id: 'safehouses',  label: 'Safehouses',        icon: '🏠', official: 13, extras: 0, desc: '8 purchasable + 3 story + Ridgewood + Plainview.' },
  { id: 'collectibles',label: 'Collectibles',      icon: '💎', official: 0,  extras: 15, desc: 'Treasure maps, flowers, extras.' },
];

// ---------------------------------------------------------------------------
// SEED — named highlights + padded generic entries so rollups match totals
// ---------------------------------------------------------------------------
const NAMED = {
  story: [
    'Exodus in America', 'The Sheriff of Armadillo', 'New Friends, Old Problems',
    "Obstacles in Our Path", 'This is Armadillo, USA', 'Political Realities in Armadillo',
    'Justice in Pike’s Basin', 'Spare the Rod, Spoil the Bandit', 'The Burning',
    'Old Swindler Blues', 'Wild Horses, Tamed Passions', 'The Assault on Fort Mercer',
    'Landon Ricketts Rides Again', 'The Demon Drink', 'Empty Promises',
    'Cowards Die Many Times', 'Man is Born Unto Trouble', 'We Shall Be Together in Paradise',
    'My Sister’s Keeper', 'Father Abraham', 'The Gunslinger’s Tragedy',
    'The Mexican Wagon Train', 'Captain De Santa’s Downfall', 'The Great Mexican Train Robbery',
    'An Appointed Time', 'The Gates of El Presidio', 'Must a Savior Die?',
    'Let the Dead Bury Their Dead', 'Great Men Are Not Always Wise', 'Bear One Another’s Burdens',
    'Mexican Caesar', 'The Demon Drink II', 'And You Will Know the Truth',
    'Off the Beaten Trail', 'The Prodigal Son Returns (Kinda)', 'And the Truth Will Set You Free',
    'At Home with Dutch', 'For Purely Scientific Purposes', 'American Lobbyists',
    'A Continual Feast', 'Whores, Damned Whores and Statistics', 'Love is the Opiate',
    'Marston and Son', 'The Outlaw’s Return', 'Wolves, Man', 'Old Habits',
    'The Prodigal Son Returns Again', 'A Tempest Looms', 'The Last Enemy That Shall Be Destroyed',
    'Remember My Family', 'Remember, My Family', 'The Outlaw’s Return II',
    'Ain’t Living Long Like This', 'Great Horse of Yore', 'Killing Time',
    'John Marston and Son', 'The Last Enemy',
  ],
  strangers: [
    'California', 'Water and Honesty', 'Poppycock', 'Lights, Camera, Action',
    'American Appetites', 'Aztec Gold', 'Deadalus and Son', 'Eva in Peril',
    'Flowers for a Lady', 'Funny Man', 'Let No Man Put Asunder', 'Love in Elegance',
    'Missus Rose', 'Remember My Family (Stranger)', 'The Wronged Woman',
    'Where the Buzzards Roam', 'You Shall Not Give False Testimony', 'Jenny’s Faith',
  ],
  challenges: ['Sharpshooter', 'Survivalist', 'Master Hunter', 'Treasure Hunter'],
  bounties: [
    'Rattlesnake Hollow', 'Twin Rocks', 'Tumbleweed', 'Río del Toro',
    'Coot’s Chapel', 'Pike’s Basin', 'Gaptooth Breach', 'Rathskeller Fork',
    'El Presidio', 'Plata Grande', 'Chuparosa', 'Torquemada',
    'Sepulcro', 'Escalera', 'Casa Madrugada', 'Nosalida',
    'Aurora Basin', 'Manzanita Post', 'Beecher’s Hope', 'Blackwater',
  ],
  jobs: [
    'Nightwatch — MacFarlane’s Ranch', 'Nightwatch — Chuparosa', 'Nightwatch — Blackwater',
    'Horsebreaking — Ridgewood Farm', 'Horsebreaking — Chuparosa',
  ],
  hideouts: [
    'Fort Mercer', 'Twin Rocks', 'Pike’s Basin', 'Gaptooth Breach',
    'Nosalida', 'Tesoro Azul', 'Tumbleweed',
  ],
  minigames: ['Poker', 'Blackjack', 'Liar’s Dice', 'Horseshoes', 'Five Finger Fillet', 'Arm Wrestling'],
  outfits: [
    'Rancher', 'Elegant Suit', 'Reyes’ Rebels', 'US Army',
    'Bollard Twins Gang', 'Treasure Hunter', 'Bandito', 'Duster',
    'Legend of the West',
  ],
  weapons: ['LeMat Revolver', 'Semi-Auto Shotgun', 'Carcano Rifle', 'Mauser Pistol', 'Evans Repeater'],
  safehouses: [
    'Armadillo Room', 'Thieves’ Landing Room', 'Chuparosa Room', 'Casa Madrugada Room',
    'Escalera Room', 'Blackwater Hotel', 'Manzanita Post Room', 'MacFarlane’s Ranch Bunk',
    'Beecher’s Hope (Story)', 'El Presidio (Story)', 'Fort Mercer (Story)',
    'Ridgewood Farm', 'Plainview Room',
  ],
  locations: [], collectibles: [],
};

function build(catId) {
  const meta = CATEGORIES.find((c) => c.id === catId);
  const named = NAMED[catId] || [];
  const items = [];
  for (let i = 0; i < meta.official; i++) {
    items.push({
      id: `${catId}-o-${i + 1}`,
      title: named[i] || `${meta.label} #${i + 1}`,
      category: catId,
      official: true,
      region: '—',
      summary: 'Required for official 100% completion.',
    });
  }
  for (let i = 0; i < meta.extras; i++) {
    items.push({
      id: `${catId}-x-${i + 1}`,
      title: named[meta.official + i] || `${meta.label} extra #${i + 1}`,
      category: catId,
      official: false,
      region: '—',
      summary: 'Completionist extra — not required for official 100%.',
    });
  }
  return items;
}

const ALL_ITEMS = CATEGORIES.flatMap((c) => build(c.id));
const BY_CAT = Object.fromEntries(CATEGORIES.map((c) => [c.id, ALL_ITEMS.filter((i) => i.category === c.id)]));

// ---------------------------------------------------------------------------
// PROGRESS STORE (tiny hand-rolled, AsyncStorage-backed if available)
// ---------------------------------------------------------------------------
const STORAGE_KEY = 'rdr1-progress-v1';
let progressState = { items: {}, notes: {}, pinned: {} };
const listeners = new Set();

async function hydrate() {
  if (!AsyncStorage) return;
  try {
    const raw = await AsyncStorage.getItem(STORAGE_KEY);
    if (raw) progressState = { items: {}, notes: {}, pinned: {}, ...JSON.parse(raw) };
    listeners.forEach((l) => l());
  } catch {}
}
async function persist() {
  if (!AsyncStorage) return;
  try { await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(progressState)); } catch {}
}
function useProgress() {
  const [, force] = useState(0);
  useEffect(() => {
    const l = () => force((n) => n + 1);
    listeners.add(l);
    return () => listeners.delete(l);
  }, []);
  return progressState;
}
function toggleDone(id) {
  progressState = { ...progressState, items: { ...progressState.items, [id]: !progressState.items[id] } };
  listeners.forEach((l) => l()); persist();
}
function togglePin(id) {
  progressState = { ...progressState, pinned: { ...progressState.pinned, [id]: !progressState.pinned[id] } };
  listeners.forEach((l) => l()); persist();
}
function setNote(id, v) {
  progressState = { ...progressState, notes: { ...progressState.notes, [id]: v } };
  listeners.forEach((l) => l()); persist();
}
function resetAll() {
  progressState = { items: {}, notes: {}, pinned: {} };
  listeners.forEach((l) => l()); persist();
}
function importJSON(text) {
  try {
    const parsed = JSON.parse(text);
    progressState = { items: {}, notes: {}, pinned: {}, ...parsed };
    listeners.forEach((l) => l()); persist();
    return true;
  } catch { return false; }
}

// Rollups
function rollup(filterFn) {
  const items = ALL_ITEMS.filter(filterFn);
  const done = items.filter((i) => progressState.items[i.id]).length;
  const total = items.length;
  return { done, total, pct: total ? Math.round((done / total) * 100) : 0 };
}

// ---------------------------------------------------------------------------
// UI PRIMITIVES
// ---------------------------------------------------------------------------
function ProgressBar({ pct, tint = T.brass }) {
  return (
    <View style={styles.track}>
      <View style={[styles.fill, { width: `${Math.max(0, Math.min(100, pct))}%`, backgroundColor: tint }]} />
    </View>
  );
}
function StatBlock({ label, done, total, pct, tint }) {
  return (
    <View style={{ marginBottom: 12 }}>
      <View style={styles.rowBetween}>
        <Text style={styles.statLabel}>{label}</Text>
        <Text style={[styles.statValue, { color: tint || T.parchment }]}>{done}/{total} · {pct}%</Text>
      </View>
      <ProgressBar pct={pct} tint={tint} />
    </View>
  );
}
function Btn({ label, onPress, kind = 'default' }) {
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.btn,
        kind === 'primary' && { borderColor: T.brass },
        kind === 'danger' && { borderColor: '#a83a2a' },
        pressed && { opacity: 0.8 },
      ]}
    >
      <Text style={[styles.btnTxt, kind === 'danger' && { color: '#e39a8a' }]}>{label}</Text>
    </Pressable>
  );
}

// ---------------------------------------------------------------------------
// SCREENS
// ---------------------------------------------------------------------------
function Dashboard({ onOpenCategory, onOpenMap, onOpenSettings, cols }) {
  useProgress();
  const off = rollup((i) => i.official);
  const ext = rollup((i) => !i.official);
  const all = rollup(() => true);

  return (
    <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 60 }}>
      <Text style={styles.eyebrow}>Red Dead Redemption</Text>
      <Text style={styles.h1}>Completionist Guide</Text>
      <Text style={styles.tagline}>John Marston's road to 100% — official tracking + completionist extras.</Text>

      <View style={styles.card}>
        <StatBlock label="Official 100%" {...off} tint={T.official} />
        <StatBlock label="Completionist Extras" {...ext} tint={T.extra} />
        <StatBlock label="Overall" {...all} tint={T.parchment} />
      </View>

      <View style={{ flexDirection: 'row', gap: 10, marginBottom: 18 }}>
        <View style={{ flex: 1 }}><Btn label="Map & Links" onPress={onOpenMap} /></View>
        <View style={{ flex: 1 }}><Btn label="Import / Export" onPress={onOpenSettings} /></View>
      </View>

      <Text style={styles.sectionHead}>Categories</Text>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', marginHorizontal: -6 }}>
        {CATEGORIES.map((c) => {
          const co = rollup((i) => i.category === c.id && i.official);
          const cx = rollup((i) => i.category === c.id && !i.official);
          return (
            <View key={c.id} style={{ width: `${100 / cols}%`, padding: 6 }}>
              <Pressable onPress={() => onOpenCategory(c.id)} style={({ pressed }) => [styles.card, pressed && { opacity: 0.85 }]}>
                <View style={{ flexDirection: 'row', gap: 12, marginBottom: 12 }}>
                  <Text style={{ fontSize: 28 }}>{c.icon}</Text>
                  <View style={{ flex: 1 }}>
                    <Text style={styles.cardTitle}>{c.label}</Text>
                    <Text style={styles.cardDesc} numberOfLines={2}>{c.desc}</Text>
                  </View>
                </View>
                {co.total > 0 && <StatBlock label="Official" {...co} tint={T.official} />}
                {cx.total > 0 && <StatBlock label="Extras" {...cx} tint={T.extra} />}
              </Pressable>
            </View>
          );
        })}
      </View>
    </ScrollView>
  );
}

function CategoryView({ categoryId, onOpenItem, activeItemId }) {
  useProgress();
  const cat = CATEGORIES.find((c) => c.id === categoryId);
  const [q, setQ] = useState('');
  const [filter, setFilter] = useState('all'); // all | official | extras | pinned | todo
  const items = BY_CAT[categoryId] || [];
  const shown = items.filter((it) => {
    if (q && !it.title.toLowerCase().includes(q.toLowerCase())) return false;
    if (filter === 'official' && !it.official) return false;
    if (filter === 'extras' && it.official) return false;
    if (filter === 'pinned' && !progressState.pinned[it.id]) return false;
    if (filter === 'todo' && progressState.items[it.id]) return false;
    return true;
  });

  return (
    <View style={{ flex: 1 }}>
      <View style={{ padding: 14, borderBottomWidth: 1, borderBottomColor: T.border }}>
        <Text style={styles.h2}>{cat?.icon} {cat?.label}</Text>
        <TextInput
          value={q}
          onChangeText={setQ}
          placeholder="Search…"
          placeholderTextColor={T.muted}
          style={styles.input}
        />
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginTop: 8 }}>
          {['all', 'official', 'extras', 'pinned', 'todo'].map((f) => (
            <Pressable key={f} onPress={() => setFilter(f)} style={[styles.chip, filter === f && styles.chipActive]}>
              <Text style={[styles.chipTxt, filter === f && { color: T.bg }]}>{f}</Text>
            </Pressable>
          ))}
        </View>
      </View>
      <FlatList
        data={shown}
        keyExtractor={(i) => i.id}
        renderItem={({ item }) => {
          const done = !!progressState.items[item.id];
          const pinned = !!progressState.pinned[item.id];
          return (
            <Pressable
              onPress={() => onOpenItem(item.id)}
              style={({ pressed }) => [styles.row, item.id === activeItemId && { backgroundColor: T.bgElev }, pressed && { opacity: 0.85 }]}
            >
              <Pressable hitSlop={8} onPress={() => toggleDone(item.id)} style={[styles.checkbox, done && styles.checkboxDone]}>
                {done ? <Text style={styles.tick}>✓</Text> : null}
              </Pressable>
              <View style={{ flex: 1 }}>
                <Text style={[styles.rowTitle, done && styles.rowDone]} numberOfLines={1}>
                  {pinned ? '★ ' : ''}{item.title}
                </Text>
                <Text style={styles.rowMeta}>{item.official ? 'Official 100%' : 'Extra'}</Text>
              </View>
            </Pressable>
          );
        }}
        ListEmptyComponent={<Text style={{ padding: 20, color: T.muted }}>No entries.</Text>}
      />
    </View>
  );
}

function DetailView({ itemId }) {
  useProgress();
  const item = ALL_ITEMS.find((i) => i.id === itemId);
  if (!item) return <View style={{ padding: 20 }}><Text style={{ color: T.muted }}>Select an entry from the list.</Text></View>;
  const done = !!progressState.items[item.id];
  const pinned = !!progressState.pinned[item.id];
  const note = progressState.notes[item.id] || '';
  return (
    <ScrollView contentContainerStyle={{ padding: 20 }}>
      <Text style={styles.eyebrow}>{item.official ? 'Official 100%' : 'Completionist Extra'}</Text>
      <Text style={styles.h2}>{item.title}</Text>
      <Text style={{ color: T.parchmentDim, marginTop: 8 }}>{item.summary}</Text>

      <View style={{ flexDirection: 'row', gap: 10, marginTop: 16 }}>
        <View style={{ flex: 1 }}><Btn label={done ? '✓ Completed' : 'Mark complete'} kind={done ? 'primary' : 'default'} onPress={() => toggleDone(item.id)} /></View>
        <View style={{ flex: 1 }}><Btn label={pinned ? '★ Pinned' : 'Pin'} onPress={() => togglePin(item.id)} /></View>
      </View>

      <Text style={[styles.sectionHead, { marginTop: 20 }]}>Personal notes</Text>
      <TextInput
        value={note}
        onChangeText={(v) => setNote(item.id, v)}
        placeholder="Location tips, missable warnings, …"
        placeholderTextColor={T.muted}
        multiline
        style={[styles.input, { minHeight: 120, textAlignVertical: 'top' }]}
      />
    </ScrollView>
  );
}

function MapView() {
  const open = (url) => Linking.openURL(url).catch(() => Alert.alert('Cannot open link'));
  return (
    <ScrollView contentContainerStyle={{ padding: 20 }}>
      <Text style={styles.h2}>Map & Reference</Text>
      <Text style={{ color: T.parchmentDim, marginTop: 6, marginBottom: 16 }}>
        External interactive maps open in your browser — most reliable on mobile.
      </Text>
      <Btn label="Open IGN Interactive Map" kind="primary" onPress={() => open('https://www.ign.com/wikis/red-dead-redemption/Interactive_Map')} />
      <View style={{ height: 10 }} />
      <Btn label="Open Fandom Wiki Map" onPress={() => open('https://reddead.fandom.com/wiki/Red_Dead_Redemption')} />
      <View style={{ height: 10 }} />
      <Btn label="100% Completion Guide (GTAForums)" onPress={() => open('https://gtaforums.com/topic/999902-rdr-100-total-completion-strategy-guide/')} />
    </ScrollView>
  );
}

function SettingsView() {
  useProgress();
  const [text, setText] = useState('');
  const exportShare = async () => {
    const json = JSON.stringify(progressState, null, 2);
    try { await Share.share({ message: json }); } catch {}
  };
  return (
    <ScrollView contentContainerStyle={{ padding: 20 }}>
      <Text style={styles.h2}>Progress</Text>
      <Text style={{ color: T.parchmentDim, marginTop: 6, marginBottom: 16 }}>
        Export progress as JSON via the native share sheet, or paste JSON below to import.
      </Text>
      <Btn label="Export via Share sheet" kind="primary" onPress={exportShare} />
      <View style={{ height: 10 }} />
      <Btn label="Reset all progress" kind="danger" onPress={() => Alert.alert('Reset?', 'This clears every checkbox.', [
        { text: 'Cancel' }, { text: 'Reset', style: 'destructive', onPress: resetAll },
      ])} />

      <Text style={[styles.sectionHead, { marginTop: 20 }]}>Import JSON</Text>
      <TextInput
        value={text}
        onChangeText={setText}
        placeholder='{"items":{...}}'
        placeholderTextColor={T.muted}
        multiline
        style={[styles.input, { minHeight: 140, textAlignVertical: 'top' }]}
      />
      <View style={{ height: 10 }} />
      <Btn label="Import" onPress={() => {
        if (importJSON(text)) { Alert.alert('Imported'); setText(''); }
        else Alert.alert('Invalid JSON');
      }} />
      {!AsyncStorage && (
        <Text style={{ color: T.accent, marginTop: 16 }}>
          Note: @react-native-async-storage/async-storage is not installed — progress won't persist across reloads. Add it in the Snack Dependencies panel to enable persistence.
        </Text>
      )}
    </ScrollView>
  );
}

// ---------------------------------------------------------------------------
// APP SHELL — tab bar + optional master/detail on tablet landscape
// ---------------------------------------------------------------------------
export default function App() {
  useEffect(() => { hydrate(); }, []);
  const { width, height } = useWindowDimensions();
  const isTablet = Math.min(width, height) >= 700;
  const isLandscape = width > height;
  const splitMode = isTablet && isLandscape;
  const cols = width > 1100 ? 3 : width > 700 ? 2 : 1;

  const [tab, setTab] = useState('home'); // home | map | settings
  const [categoryId, setCategoryId] = useState(null);
  const [itemId, setItemId] = useState(null);

  const openCategory = (id) => { setCategoryId(id); setItemId(null); setTab('home'); };
  const openItem = (id) => setItemId(id);
  const back = () => {
    if (itemId && !splitMode) return setItemId(null);
    if (categoryId) return setCategoryId(null);
  };

  let content;
  if (tab === 'map') content = <MapView />;
  else if (tab === 'settings') content = <SettingsView />;
  else if (categoryId && splitMode) {
    content = (
      <View style={{ flex: 1, flexDirection: 'row' }}>
        <View style={{ width: 380, borderRightWidth: 1, borderRightColor: T.border }}>
          <CategoryView categoryId={categoryId} onOpenItem={openItem} activeItemId={itemId} />
        </View>
        <View style={{ flex: 1 }}>
          <DetailView itemId={itemId} />
        </View>
      </View>
    );
  } else if (categoryId && itemId) {
    content = <DetailView itemId={itemId} />;
  } else if (categoryId) {
    content = <CategoryView categoryId={categoryId} onOpenItem={openItem} />;
  } else {
    content = <Dashboard cols={cols} onOpenCategory={openCategory} onOpenMap={() => setTab('map')} onOpenSettings={() => setTab('settings')} />;
  }

  const title =
    tab === 'map' ? 'Map & Reference' :
    tab === 'settings' ? 'Progress' :
    itemId && !splitMode ? 'Details' :
    categoryId ? (CATEGORIES.find((c) => c.id === categoryId)?.label || '') :
    'RDR1 Completionist';

  const canBack = tab === 'home' && !!categoryId;

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: T.bg }}>
      <StatusBar barStyle="light-content" backgroundColor={T.bg} />
      <View style={styles.header}>
        {canBack ? (
          <Pressable onPress={back} hitSlop={10}><Text style={styles.headerBack}>‹ Back</Text></Pressable>
        ) : <View style={{ width: 60 }} />}
        <Text style={styles.headerTitle} numberOfLines={1}>{title}</Text>
        <View style={{ width: 60 }} />
      </View>

      <View style={{ flex: 1 }}>{content}</View>

      <View style={styles.tabBar}>
        {[
          { id: 'home', label: 'Guide', glyph: '★' },
          { id: 'map', label: 'Map', glyph: '🗺' },
          { id: 'settings', label: 'Progress', glyph: '⚙' },
        ].map((t) => (
          <Pressable key={t.id} onPress={() => { setTab(t.id); if (t.id !== 'home') { setCategoryId(null); setItemId(null); } }} style={styles.tab}>
            <Text style={{ fontSize: 18, color: tab === t.id ? T.brass : T.muted }}>{t.glyph}</Text>
            <Text style={{ fontSize: 11, marginTop: 2, color: tab === t.id ? T.brass : T.muted }}>{t.label}</Text>
          </Pressable>
        ))}
      </View>
    </SafeAreaView>
  );
}

// ---------------------------------------------------------------------------
// STYLES
// ---------------------------------------------------------------------------
const styles = StyleSheet.create({
  header: {
    height: 48, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 12, borderBottomWidth: 1, borderBottomColor: T.border, backgroundColor: T.bgElev,
  },
  headerTitle: { color: T.parchment, fontSize: 16, fontWeight: '700', flex: 1, textAlign: 'center', fontFamily: Platform.select({ ios: 'Georgia', default: undefined }) },
  headerBack: { color: T.brass, fontSize: 16, width: 60 },
  tabBar: { flexDirection: 'row', borderTopWidth: 1, borderTopColor: T.border, backgroundColor: T.bgElev },
  tab: { flex: 1, paddingVertical: 8, alignItems: 'center' },

  eyebrow: { color: T.brass, letterSpacing: 2, fontSize: 11, textTransform: 'uppercase' },
  h1: { color: T.parchment, fontSize: 30, fontWeight: '700', marginTop: 4, fontFamily: Platform.select({ ios: 'Georgia', default: undefined }) },
  h2: { color: T.parchment, fontSize: 22, fontWeight: '700', fontFamily: Platform.select({ ios: 'Georgia', default: undefined }) },
  tagline: { color: T.parchmentDim, fontSize: 14, marginTop: 8, marginBottom: 16 },
  sectionHead: { color: T.brass, fontSize: 11, letterSpacing: 1.5, textTransform: 'uppercase', fontWeight: '700', marginBottom: 10 },

  card: { backgroundColor: T.surface, borderRadius: 14, borderWidth: 1, borderColor: T.border, padding: 16, marginBottom: 12 },
  cardTitle: { color: T.parchment, fontSize: 16, fontWeight: '700' },
  cardDesc: { color: T.muted, fontSize: 12, marginTop: 2 },

  rowBetween: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  statLabel: { color: T.parchmentDim, fontSize: 12, letterSpacing: 0.5, textTransform: 'uppercase' },
  statValue: { fontVariant: ['tabular-nums'], fontWeight: '600' },
  track: { height: 6, backgroundColor: T.bgElev, borderRadius: 999, overflow: 'hidden', borderWidth: 1, borderColor: T.border, marginTop: 4 },
  fill: { height: '100%', borderRadius: 999 },

  btn: { padding: 12, borderRadius: 10, borderWidth: 1, borderColor: T.borderStrong, backgroundColor: T.bgElev, alignItems: 'center' },
  btnTxt: { color: T.brass, fontWeight: '700', letterSpacing: 0.6 },

  input: { marginTop: 10, backgroundColor: T.bg, borderWidth: 1, borderColor: T.border, borderRadius: 8, padding: 10, color: T.parchment },

  chip: { paddingHorizontal: 10, paddingVertical: 5, borderRadius: 999, borderWidth: 1, borderColor: T.border, backgroundColor: T.bgElev },
  chipActive: { backgroundColor: T.brass, borderColor: T.brass },
  chipTxt: { color: T.parchmentDim, fontSize: 12, textTransform: 'capitalize' },

  row: { flexDirection: 'row', alignItems: 'center', padding: 12, gap: 12, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: T.border },
  checkbox: { width: 22, height: 22, borderRadius: 4, borderWidth: 1.5, borderColor: T.borderStrong, alignItems: 'center', justifyContent: 'center', backgroundColor: T.bg },
  checkboxDone: { backgroundColor: T.brass, borderColor: T.brass },
  tick: { color: T.bg, fontWeight: '800', fontSize: 14 },
  rowTitle: { color: T.parchment, fontSize: 15, fontWeight: '600' },
  rowDone: { color: T.muted, textDecorationLine: 'line-through' },
  rowMeta: { color: T.muted, fontSize: 12, marginTop: 2 },
});
