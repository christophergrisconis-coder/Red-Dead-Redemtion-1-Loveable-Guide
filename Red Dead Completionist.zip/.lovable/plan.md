## Goal

Fix the guide so every category cleanly separates **Official 100% requirements** (IGN-verified) from **Completionist Extras** (custom tracking). Correct wrong totals, extend the schema so the UI derives dual counts from records, and add a validator that flags any mismatch against IGN expectations.

## Scope

Keep the existing tablet-first shell, routes, styling, progress store, import/export, and same-page map panel unchanged. Only touch: the data schema, category data files, dashboard cards, and the dataset health panel.

## 1. Schema changes (`src/data/types.ts`)

Add two explicit flags plus an optional subtype on `TrackableBase`:

- `isOfficial100: boolean` — counts toward the IGN-verified official 100% checklist. Source of truth.
- `isCompletionistExtra: boolean` — tracked in-app for completionists but not part of official 100%.
- `categorySubtype?: string` — e.g. `"rare-weapon"`, `"completionist-weapon"`, `"official-hideout"`, `"outfit-scrap-chain"`, `"map-discovery"`, `"outfit-optional"`.

Keep `isRequiredForOfficial100` as a deprecated alias (mirrors `isOfficial100`) so no existing route/component breaks. Every record is `official XOR extra` — a small assertion helper validates this at module load.

## 2. Corrected official totals (IGN reference)

| Category | Official 100% | Notes |
|---|---|---|
| Story Missions | 57 | All official. |
| Stranger Missions | 18 | 19 total, "I Know You" flagged `isCompletionistExtra`. |
| Challenges | 4 chains | Tomahawk + Explosive Rifle stay as extras. Ranks tracked internally. |
| Bounties | 20 | 8 New Austin + 8 Nuevo Paraíso + 4 West Elizabeth. |
| Jobs | 5 | 3 Nightwatch + 2 Horsebreaking. |
| Gang Hideouts | 7 | Per user spec — promote Tumbleweed to official; Solomon's Folly stays extra. |
| Minigames | 6 | Horseshoes, Blackjack, Five Finger Fillet, Liar's Dice, Arm Wrestling, Poker. |
| Locations | 94 | Prune current 98 to the IGN-verified 94; move surplus 4 to extras (or delete). |
| Outfits | Split | Split existing 12 into IGN "official" outfit set vs optional/aesthetic extras. Card shows both lines. |
| Weapons | 5 rare | LeMat, Semi-Auto Shotgun, Carcano, Mauser, Evans Repeater. All other weapons flagged extra. |
| Safehouses | 11 | 8 purchasable + 3 story-granted; Ridgewood / Plainview stay extras. |
| Collectibles | 0 official | Relabel this category as **Completionist Tracking** — Treasure Maps roll into the Challenges rollup, Wild Flowers roll into Survivalist. Card and route header updated to say "Completionist Tracking" (not "required for 100%"). |

## 3. Data file patches

Non-destructive edits — no rewrites — just flag flips and small pruning:

- `weapons.ts` — set `isOfficial100: true` only on the 5 rare weapons, everything else `isCompletionistExtra`.
- `hideouts.ts` — promote Tumbleweed to `isOfficial100: true`; keep Solomon's Folly as extra.
- `locations.ts` — audit against IGN's Locations list, keep 94 as official, move the surplus 4 to extras with `categorySubtype: "completionist-location"`.
- `outfits.ts` — split into `official` (Cowboy, Elegant Suit, Bollard Twins, Treasure Hunter, Bandito, Reyes' Rebels, US Army, US Marshal, Mexican Poncho, Rancher, Legend of the West, Bureau) vs `extras` (Walton's, Deadly Assassin, Expert Hunter, Savvy Merchant, Duster, Gentleman's). Both sub-counts surface on the card.
- `collectibles.ts` — flag all entries `isCompletionistExtra`, no official count.
- `strangers.ts` — confirm "I Know You" flagged extra (already the case).
- `challenges.ts` — Tomahawk + Explosive Rifle stay flagged extra (already correct).

## 4. Validator (`src/data/index.ts`)

Replace `EXPECTED_COUNTS` entries with a richer shape:

```ts
{ categoryId, label,
  expectedOfficial: number,
  expectedCompletionistTotal?: number,   // optional for extras-only categories
  officialRequirementText: string,       // human summary
  note?: string }                        // e.g. "Completionist tracking only"
```

Update `computeDatasetStats()` to return both counts per category and a `mismatches[]` list. Flags fire when actual official ≠ expected (e.g. locations != 94, story != 57, bounties != 20, strangers official != 18, hideouts official != 7).

`computeDatasetHealth()` grows a `mismatchCount` field.

## 5. UI updates

- **Homepage `CategoryCard`** — replace single "X / Y" with a dual layout:
  ```
  Official     12 / 57
  Completionist 12 / 57
  ```
  Categories with no official requirement (collectibles) show a single "Completionist Tracking" line and a subtle "Not part of official 100%" caption.
- **Homepage top stats** — keep "Official 100%" and "Completionist" tiles unchanged (already dual).
- **`DatasetHealthPanel`** — add columns for `Official actual / expected`, `Extras`, and a "Mismatches" strip up top listing any flagged category with the reason (e.g. "Locations: 98 official records, expected 94").
- **Category route pages** (`CategoryPage`) — add a small header pill: "Official" vs "Completionist tracking" vs "Mixed (X official + Y extras)". Filter dropdown so the user can toggle a page to only-official or all.

## 6. Progress rollups (`src/lib/progress.ts`)

- `useOfficialRollup` already keys off `isRequiredForOfficial100` → adjust to `isOfficial100` (aliased so nothing breaks).
- Add `useOfficialCategoryRollup(cat)` and `useCompletionistCategoryRollup(cat)` so cards can render both lines cheaply.

## 7. Verification

- Typecheck clean.
- Load `/` — every card shows dual totals; official numbers match the table above.
- Load `/reference` (or the dashboard panel) — validator shows all categories `OK` with no mismatches; forcing a bad number should light up the mismatches strip.

## Out of scope

No new routes, no restyling, no map panel changes, no touching the progress store shape (item-level flags stay identical).
